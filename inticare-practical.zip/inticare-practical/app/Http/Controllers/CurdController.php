<?php

namespace App\Http\Controllers;

use App\Models\Form;
use Illuminate\Http\Request;
use DataTables, Session;

class CurdController extends Controller
{
    //

    public function view(Request $request)
    {
        if ($request->ajax()) {
            $form = new Form;
            $data = $form->GetFormActiveData();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $url = route('edit',['form_id' => $row->form_id]);
                    $btn = '<a href="'.$url.'" class="edit btn btn-primary btn-sm" id="' . $row->form_id . '" onclick="edit(' . $row->form_id . ')">Edit</a> <a href="javascript:void(0)" class="delete btn btn-danger btn-sm" id="' . $row->form_id . '" onclick="delete(' . $row->form_id . ')">Delete</a>';
                    return $btn;
                })
                ->addColumn('image', function ($row) {
                    $url_image = asset("public/uploads/image/$row->image");
                    $img = '<img src="' . $url_image . '" class="img-fluid" height="100px" width="100px"></img>';
                    return $img;
                })
                ->addColumn('file', function ($row) {
                    $url_file = asset("public/uploads/file/$row->file");
                    $file = '<a href="' . $url_file . '" class="text-decoration-none">'.$row->file.'</a>';
                    return $file;
                })
                ->rawColumns(['action', 'image','file'])
                ->make(true);
        } else {
            return view('curd');
        }
    }

    public function add()
    {
        return view('add');
    }
    public function edit(Request $request,$form_id)
    {
        $get_form_data = Form::find($form_id);
        return view('edit',compact('get_form_data'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|numeric|digits:10',
            'gender' => 'required',
            'image' => 'required|image',
            'file' => 'required|file',
        ]);
        $filename = time() . $request->file('file')->getClientOriginalName();
        $Imagename = time() . $request->file('image')->getClientOriginalName();
        $request->image->move(public_path('uploads/image/'), $Imagename);
        $request->file->move(public_path('uploads/file/'), $filename);
        $form = new Form;
        $form->name = $request->name;
        $form->email = $request->email;
        $form->phone = $request->phone;
        $form->gender = $request->gender;
        $form->image = $Imagename;
        $form->file = $filename;
        $save = $form->save();
        if ($save) {
            return redirect()->route('view')->with('success', 'Form Submitted Succesfully!');
        } else {
            return redirect()->route('view')->with('error', 'Something Went Wrong');
        }
    }
    public function edit_store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|numeric|digits:10',
            'gender' => 'required',
        ]);
       
        $form = Form::find($request->form_id);
        $form->name = $request->name;
        $form->email = $request->email;
        $form->phone = $request->phone;
        $form->gender = $request->gender;
        if ($request->file) {
            $filename = time() . $request->file('file')->getClientOriginalName();
            $request->file->move(public_path('uploads/file/'), $filename);
            $form->file = $filename;
        }
        if ($request->image) {
            $Imagename = time() . $request->file('image')->getClientOriginalName();
            $request->image->move(public_path('uploads/image/'), $Imagename);
            $form->image = $Imagename;
        }
        $save = $form->save();
        if ($save) {
            return redirect()->route('view')->with('success', 'Form Updated Succesfully!');
        } else {
            return redirect()->route('view')->with('error', 'Something Went Wrong');
        }
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'form_id' => 'required',
        ]);

        $form = Form::find($request->form_id);
        $form->is_deleted = '1';
        $form->updated_at = date('Y-m-d H:i:s');
        $save = $form->save();
        if ($save) {
            // Save the message in the session
            Session::flash('success', 'Deleted Successfully');

            // Return the success message as part of the JSON response
            return response()->json(['message' => 'Deleted Successfully']);
        } else {
            // Save the message in the session
            Session::flash('error', 'Something Went Wrong');

            // Return the success message as part of the JSON response
            return response()->json(['message' => 'Something Went Wrong']);
        }
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Form extends Model
{
    use HasFactory;
    protected $table = 'tbl_form';
    protected $primaryKey = 'form_id';

    public function GetFormActiveData()
    {
        return $this->where('is_deleted','0');
    }
}
